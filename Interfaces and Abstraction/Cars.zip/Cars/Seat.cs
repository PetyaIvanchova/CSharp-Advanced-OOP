﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cars
{
    using Cars.Interfaces;
    public class Seat : ICar
    {
        public string Model { get; private set; }
        public string Color { get; private set; }
        public Seat(string model, string color)
        {
            this.Model = model;
            this.Color = color;
        }
        public string Start()
        {
            return "Start from Seat";
        }
        public string Stop()
        {
            return "Stop from Seat"; 
        }

    }
}
