﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex3.Core
{
    using Models;
    using Core.IO.Interfaces;
    public class Engine : IEngine
    {
        private readonly IReader reader;
        private readonly IWriter writer;
        private readonly Smartphone smartphone;
        private readonly StationaryPhone stationaryPhone;

        public Engine(IReader reader, IWriter writer)
            : this()
        {
            this.writer = writer;
            this.reader = reader;
        }
        private Engine()
        {
            this.stationaryPhone = new StationaryPhone();
            this.smartphone = new Smartphone();
        }
        public void Start()
        {
            string[] phonenumbers = this.reader.ReadLine().Split(' ',StringSplitOptions.RemoveEmptyEntries);
            string[] urls  = this.reader.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);

            foreach (string phonenumber in phonenumbers)
            {
                if (!this.ValidateNumber(phonenumber))
                {
                    this.writer.WriteLine("Invalid number!");
                }
                else if (phonenumber.Length==10)
                {
                    this.writer.WriteLine(this.smartphone.Call(phonenumber));
                }
                else if (phonenumber.Length==7)
                {
                    this.writer.WriteLine(this.stationaryPhone.Call(phonenumber));
                }
            }
            foreach (string url in urls)
            {
                if (!this.ValidateURL(url))
                {
                    this.writer.WriteLine("Invalid URL!");
                }
                else
                {
                    this.writer.WriteLine(this.smartphone.BrowseURL(url));
                }
            }
        }
        private bool ValidateNumber(string number)
        {
            foreach (char digit in number)
            {
                if (!Char.IsDigit(digit))
                {
                    return false;
                }
            }
            return true;
        }
        private bool ValidateURL(string url)
        {
            foreach (char ch in url)
            {
                if (char.IsDigit(ch))
                {
                    return false;
                }
            }
            return true;
        }
    }
}
