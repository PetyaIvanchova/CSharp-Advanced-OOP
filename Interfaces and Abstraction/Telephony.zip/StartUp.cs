﻿using System;
using System.Linq;

namespace Telephony
{
    using ex3.Core.IO.Interfaces;
    using ex3.IO;
    using ex3.Core;
    public class StartUp
    {
       
        static void Main(string[] args)
        {
            IReader reader = new ConsoleReader();
            IWriter writer = new ConsoleWriter();

            IEngine engine = new Engine(reader, writer);
            engine.Start();
        }
    }
}
