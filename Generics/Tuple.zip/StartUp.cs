﻿using System;

namespace Tuple
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var info = Console.ReadLine().Split();
            var fullname = info[0] +" "+ info[1];
            var city = info[2];

            var nameandbeer = Console.ReadLine().Split();
            var name = nameandbeer[0];
            var numoflit = int.Parse(nameandbeer[1]);

            var numbersinput = Console.ReadLine().Split();
            var intnum = int.Parse(numbersinput[0]);
            var doublenum = double.Parse(numbersinput[1]);

            Tuple<string, string> first = new Tuple<string, string>(fullname, city);
            Tuple<string, int> second = new Tuple<string, int>(name, numoflit);
            Tuple<int, double> third = new Tuple<int, double>(intnum, doublenum);
            Console.WriteLine(first);
            Console.WriteLine(second);
            Console.WriteLine(third);
        }
    }
}
