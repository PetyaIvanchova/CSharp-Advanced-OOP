﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tuple
{
    public class Tuple<TFirst ,TSecond>
    {
        public Tuple(TFirst firstel,TSecond secondel)
        {
            Firstelement = firstel;
            Secondelement = secondel;
        }
        public TFirst Firstelement { get; private set; }
        public TSecond Secondelement { get; private set; }
        public override string ToString()
        {
            return $"{Firstelement} -> {Secondelement}";
        }
    }
}
