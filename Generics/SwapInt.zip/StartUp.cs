﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Box
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var numbers = int.Parse(Console.ReadLine());
            var list = new List<int>();
            for (int i = 0; i < numbers; i++)
            {
                var input = int.Parse(Console.ReadLine());
                list.Add(input);
            }
            var box = new Box<int>(list);
            var index = Console.ReadLine().Split().Select(int.Parse).ToArray();
            box.Swap(list, index[0], index[1]);
            Console.WriteLine(box);
        }
    }
}
