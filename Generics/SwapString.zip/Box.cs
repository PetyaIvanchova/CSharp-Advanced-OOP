﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box
{
   public class Box<T>
    {
        public Box(T element)
        {
            Element = element;
        }
        public Box(List<T> elementslist)
        {
            Elements = elementslist;
        }
        public T Element { get; }
        public List<T> Elements { get; }
        public void Swap(List<T> elements,int one,int two)
        {
            T firstEl = elements[one];
            elements[one] = elements[two];
            elements[two] = firstEl;
        }
        public override string ToString()
        {
            var sb = new StringBuilder();
            foreach (T element in Elements)
            {
                sb.AppendLine($"{element.GetType()}: {element}");
            }
            return sb.ToString().TrimEnd();
        }
    }
}
