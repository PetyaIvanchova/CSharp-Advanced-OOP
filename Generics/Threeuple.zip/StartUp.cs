﻿using System;

namespace Threeuple
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var info = Console.ReadLine().Split();
            var fullname = info[0] + " " + info[1];
            var address = info[2];
            var city = info[3];

            var nameandbeer = Console.ReadLine().Split();
            var name = nameandbeer[0];
            var numoflit = int.Parse(nameandbeer[1]);
            var isDrunke = nameandbeer[2]=="drunk"? true : false;

            var numbersinput = Console.ReadLine().Split();
            var namebank =(numbersinput[0]);
            var doublenum = double.Parse(numbersinput[1]);
            var nameb = numbersinput[2];

            Threeuple<string, string,string> first = new Threeuple<string, string,string>(fullname, address,city);
            Threeuple<string, int,bool> second = new Threeuple<string, int,bool>(name, numoflit, isDrunke);
            Threeuple<string, double,string> third = new Threeuple<string, double,string>(namebank, doublenum, nameb);
            Console.WriteLine(first);
            Console.WriteLine(second);
            Console.WriteLine(third);
        }
    }
}
