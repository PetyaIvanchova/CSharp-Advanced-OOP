﻿using System;
using System.Collections.Generic;

namespace Box
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var numbers = int.Parse(Console.ReadLine());
            var list = new List<string>();
            for (int i = 0; i < numbers; i++)
            {
                var input = (Console.ReadLine());
                list.Add(input);
            }
            var box = new Box<string>(list);
            var index = Console.ReadLine();
            var count = box.CountGreate(list, index);
            Console.WriteLine(count);
        }
    }
}
