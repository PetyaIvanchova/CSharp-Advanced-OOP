﻿using System;
using System.Collections.Generic;

namespace Box
{
    class StartUp
    {
        static void Main(string[] args)
        {

            var numbers = int.Parse(Console.ReadLine());
            var list = new List<double>();
            for (int i = 0; i < numbers; i++)
            {
                var input =double.Parse(Console.ReadLine());
                list.Add(input);
            }
            var box = new Box<double>(list);
            var index = double.Parse(Console.ReadLine());
            var count = box.CountGreate(list, index);
            Console.WriteLine(count);
        }
    }
}
