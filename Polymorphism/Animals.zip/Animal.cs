﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animals
{
    public class Animal
    {
        private string name;
        private string favouritefood;
        public string Name { get; set; }
        public string FavouriteFood { get; set; }
        public Animal(string name,string favouritefood)
        {
            this.Name = name;
            this.FavouriteFood = favouritefood;
        }
        public virtual string ExplainSelf()
        {
            return $"I am {this.Name} and my favourite food is {this.FavouriteFood}";

        }

    }
}
