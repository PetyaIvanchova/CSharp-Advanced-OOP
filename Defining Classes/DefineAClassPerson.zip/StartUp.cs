﻿using System;

namespace DefiningClasses
{
   public  class StartUp
    {
        static void Main(string[] args)
        {
            Person first = new Person("Peter", 20);
            Person second = new Person();
            {
                second.Name = "George";
                second.Age=18;

            }
        }
    }
}
