﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            SortedDictionary<string, int> result = new SortedDictionary<string, int>();
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string[] info = Console.ReadLine().Split().ToArray();
                string name = info[0];
                int age = int.Parse(info[1]);
                Person person = new Person(name, age);
                if (person.Age>30)
                {
                    result.Add(person.Name , person.Age);
                }
            }
            foreach (var item in result)
            {
                Console.WriteLine($"{item.Key} - {item.Value}");
            }
        }
    }
}
