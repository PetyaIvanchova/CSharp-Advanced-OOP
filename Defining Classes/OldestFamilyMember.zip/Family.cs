﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefiningClasses
{
    public class Family
    {
        private List<Person> familymembers;

        public Family()
        {
            this.familymembers = new List<Person>();
        }
        public void AddMember(Person member)
        {
            this.familymembers.Add(member);
        }
        public Person GetOldestMember()
        {
            int Maxint = this.familymembers.Max(member => member.Age);
            return familymembers.First(member => member.Age == Maxint);
        }
    }
}
