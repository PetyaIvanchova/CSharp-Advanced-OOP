﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person first = new Person();
            Person second = new Person(21);
            Person third = new Person("Ivan", 32);
        }
    }
}
