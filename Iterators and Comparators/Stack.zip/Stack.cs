﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stack
{
    public class Stack<T> : IEnumerable<T>
    {
        private List<T> collection;
        public Stack(params T[] data)
        {
            collection = new List<T>(data);
        }

        public IEnumerator<T> GetEnumerator()
        {
            for (int i = collection.Count-1; i >= 0; i--)
            {
                yield return collection[i];
            }
        }
        public void Push(params T[] elements)
        {
            foreach (var element in elements)
            {
                collection.Insert(collection.Count, element);
            }
        }
        public T Pop()
        {
            if (collection.Count==0)
            {
                throw new ArgumentException("No elements");
            }
            T element = collection[collection.Count - 1];
            collection.RemoveAt(collection.Count - 1);
            return element;
        }
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
        
           
        
    }
}
