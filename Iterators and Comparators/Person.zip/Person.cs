﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Person
{
    public class Person:IComparable<Person>
    {
        private string name;
        private int age;
        private string town;
        public Person(string name,int age,string town)
        {
            this.name = name;
            this.age = age;
            this.town = town;
        }
        public string Name => name;
        public int Age => age;
        public string Town => town;
        public int CompareTo(Person other)
        {
            int result = Name.CompareTo(other.name);
            if (result==0)
            {
                result = Age.CompareTo(other.age);
            }
            if (result==0)
            {
                result = Town.CompareTo(other.town);
            }
            return result;
        }
    }
}
