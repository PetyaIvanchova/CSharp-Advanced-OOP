﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListyIterator
{
    public class ListyIterator<T> :IEnumerator<T>
    {
        private List<T> collection;
        private int currIndex;

        public T Current => throw new NotImplementedException();

        object IEnumerator.Current => throw new NotImplementedException();

        public ListyIterator(params T[] data)
        {
            collection = new List<T>(data);
            currIndex = 0;
        }
        public bool HasNext() => currIndex < collection.Count - 1;
        public bool Move()
        {
            bool CanMove = HasNext();
            if (CanMove)
            {
                currIndex++;
            }
            return CanMove;
        }
        public void Print()
        {
            if (collection.Count == 0)
            {
                throw new ArgumentException("Invalid Operation");
            }
            Console.WriteLine($"{collection[currIndex]}");
        }
        public void PrintAll()
        {
            Console.WriteLine(string.Join(" ",collection));
        }

        public IEnumerator<T> GetEnumerator()
        {
            foreach (T element in collection)
            {
                yield return element;

            }
        }

        public bool MoveNext()
        {
            throw new NotImplementedException();
        }

        public void Reset()
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}
